package www.starcom.com.batammall.Search;

/**
 * Created by ADMIN on 20/02/2018.
 */

public class SearchHolder {
}
