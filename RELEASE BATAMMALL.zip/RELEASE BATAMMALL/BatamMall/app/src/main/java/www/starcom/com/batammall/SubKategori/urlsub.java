package www.starcom.com.batammall.SubKategori;

/**
 * Created by ADMIN on 06/02/2018.
 */

public class urlsub {

    public static String URL_SUB1(String id) {
        return  "https://batammall.co.id/ANDROID/sub1_kategori1.php?id_sub_kategori_produk="+id;
    }
}
