package www.starcom.com.batammall.Kategori;

/**
 * Created by ADMIN on 06/02/2018.
 */

public class urlkategori {

    public static String URL_kategori = "https://batammall.co.id/ANDROID/kategori1.php?id_kategori_produk=1";
    public static String URL_kategori2 = "https://batammall.co.id/ANDROID/kategori1.php?id_kategori_produk=2";
    public static String URL_kategori3 = "https://batammall.co.id/ANDROID/kategori1.php?id_kategori_produk=3";
    public static String URL_kategori4 = "https://batammall.co.id/ANDROID/kategori1.php?id_kategori_produk=4";
    public static String URL_kategori5 = "https://batammall.co.id/ANDROID/kategori1.php?id_kategori_produk=5";
    public static String URL_kategori6 = "https://batammall.co.id/ANDROID/kategori1.php?id_kategori_produk=6";
    public static String URL_kategori7 = "https://batammall.co.id/ANDROID/kategori1.php?id_kategori_produk=7";
    public static String URL_kategori8 = "https://batammall.co.id/ANDROID/kategori1.php?id_kategori_produk=8";
    public static String URL_kategori9 = "https://batammall.co.id/ANDROID/kategori1.php?id_kategori_produk=9";
    public static String URL_kategori10 = "https://batammall.co.id/ANDROID/kategori1.php?id_kategori_produk=10";
    public static String URL_kategori11 = "https://batammall.co.id/ANDROID/kategori1.php?id_kategori_produk=11";
    public static String URL_kategori12 = "https://batammall.co.id/ANDROID/kategori1.php?id_kategori_produk=12";
    public static String URL_kategori13 = "https://batammall.co.id/ANDROID/kategori1.php?id_kategori_produk=13";
    public static String URL_kategori14 = "https://batammall.co.id/ANDROID/kategori1.php?id_kategori_produk=14";
    public static String URL_kategori15 = "https://batammall.co.id/ANDROID/kategori1.php?id_kategori_produk=15";
}
