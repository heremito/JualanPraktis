package www.starcom.com.batammall.IDTansaksi;

/**
 * Created by ADMIN on 21/02/2018.
 */

public class idtransaksi {

    private String id_transaksi ;

    public idtransaksi(String id_transaksi) {
        this.id_transaksi = id_transaksi;
    }

    public String getId_transaksi() {
        return id_transaksi;
    }

    public void setId_transaksi(String id_transaksi) {
        this.id_transaksi = id_transaksi;
    }
}
