package www.starcom.com.batammall.Kategori;

/**
 * Created by ADMIN on 09/02/2018.
 */

public class SliderUtils {
    String sliderImageUrl ;

    public String getSliderImageUrl() {
        return sliderImageUrl;
    }

    public void setSliderImageUrl(String sliderImageUrl) {
        this.sliderImageUrl = sliderImageUrl;
    }
}
